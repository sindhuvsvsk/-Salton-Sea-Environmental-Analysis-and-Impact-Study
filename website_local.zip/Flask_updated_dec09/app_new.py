from flask import Flask, render_template,render_template_string, request, redirect
import folium

import requests
import json

import pandas as pd
import numpy as np
import aqi

from pandas import concat
import pickle

import tensorflow as tf
from tensorflow import keras

from datetime import datetime, time, timedelta, date
import time as t
from statistics import mean


#Modify these functions as we dont need just single row with lag features and no y value.

def series_to_supervised(data, n_in=1, n_out=1, dropnan=True):
    n_vars = 1 if type(data) is list else data.shape[1]
    df = pd.DataFrame(data)
    cols, names = list(), list()
    # input sequence (t-n, ... t-1)
    for i in range(n_in, 0, -1):
        cols.append(df.shift(i))
        names += [('var%d(t-%d)' % (j+1, i)) for j in range(n_vars)]
    # forecast sequence (t, t+1, ... t+n)
    for i in range(0, n_out):
        cols.append(df.shift(-i))
        if i == 0:
            names += [('var%d(t)' % (j+1)) for j in range(n_vars)]
        else:
            names += [('var%d(t+%d)' % (j+1, i)) for j in range(n_vars)]
    # put it all together
    agg = concat(cols, axis=1)
    agg.columns = names
    # drop rows with NaN values
    if dropnan:
        agg.dropna(inplace=True)
    return agg

def data_split(data,n_hours,n_features,reshape):
    values = data.values
    n_obs = n_hours * n_features
    QA_X, QA_y = values[:, :n_obs], values[:, -n_features]
    if reshape=='yes':
        QA_X  = QA_X.reshape((QA_X.shape[0], n_hours, n_features))
    
    return QA_X 

def AQI_cal(value,pollutant):
    
    if value <0:
        value=0
    
    if pollutant=='CO':
        if value <=50:
            maqi=aqi.to_iaqi(aqi.POLLUTANT_CO_8H, value, algo=aqi.ALGO_EPA)
        else :
            maqi=500

    elif pollutant=='OZONE':
        maqi= aqi.to_iaqi(aqi.POLLUTANT_O3_8H, value, algo=aqi.ALGO_EPA)
        
    elif pollutant=='PM25':
        if value <=500:
            maqi= aqi.to_iaqi(aqi.POLLUTANT_PM25, value, algo=aqi.ALGO_EPA)
        else:
            maqi=500
        
    elif pollutant=='PM10':
        if value <=600:
            maqi= aqi.to_iaqi(aqi.POLLUTANT_PM10, value, algo=aqi.ALGO_EPA)
        else:
            maqi=600
        
    return maqi

def AQI_level(value):
    if value <= 50:
        return "Good"
    elif value <= 100:
        return "Moderate"
    elif value <= 150:
        return "UnHealthy for Sensitive Groups"
    elif value <= 200:
        return "UnHealthy"
    elif value <= 300:
        return "Very UnHealthy"
    elif value > 300:
        return "Hazardous"
    else:
        return np.NaN
        
        
def get_today_unix(dt_in): #function to get unix time for local time
    unix_dt=int(t.mktime(dt_in.timetuple()))
    return unix_dt    


#import datetime
def change_date(dt):
    return(datetime.fromtimestamp(int(dt)).strftime('%Y-%m-%d %H:%M:%S'))

def weather_api_call(lat,long,dt,key):
    return requests.get(f'https://api.openweathermap.org/data/2.5/onecall/timemachine?lat={lat}&lon={long}&units=imperial&dt={dt}&appid={key}')
    
#Functions to change units of wind speed to knots
def wind_speed_change(wind_in):
    return (wind_in*0.868976)
    

#change unit to ppm
def ppm_unit(poll_in):
    return (0.001*poll_in)
    
def air_pollutants_api_call(lat,long,start_time,end_time,key):
  return requests.get(f'http://api.openweathermap.org/data/2.5/air_pollution/history?lat={lat}&lon={long}&start={start_time}&end={end_time}&appid={key}')

Weather_API_KEY='7872c767e8eaf7d60f3ff0970f218a4e'    
        
app = Flask(__name__) 
app.config['TEMPLATES_AUTO_RELOAD'] = True
@app.route("/") 
def home(): 
    return render_template('base.html')
   
@app.route("/hourly_prediction",methods = ['GET','POST']) 
def hourly_prediction(): 
    if request.method=='POST':
        loc_dict={"Salton City":(33.298600, -115.956100),"Bombay Beach":(33.35630316415553, -115.72964477940087),"Mecca":(33.57887179280642, -116.07629452989151),"Westmorland":(33.052182891522996, -115.62068720523438)}
        req=request.form
        city_name=req.get('city')
        cord=loc_dict[city_name]
        start_coords = loc_dict[city_name]
        #start_coords = (46.9540700, 142.7360300)
        folium_map = folium.Map(location=(33.34407936458491, -115.84208313711439), zoom_start=9)
        folium.Marker(location=start_coords,popup=city_name).add_to(folium_map)
        folium_map.save('templates/map.html')
        #Include Code for ML Models etc Here.
        #prepare data for models
        #Load scaler
        scaler=pickle.load(open('scaler.pkl', 'rb'))
        lat=start_coords[0]
        long=start_coords[1]
        #Code to Get previous 5 hours of weather data
        from datetime import datetime, time, timedelta, date
        if time(17,0) <= datetime.now().time() < time(21,0):
            #call twice by using cuurent time and time of previous date.
            dt1=get_today_unix(datetime.combine(date.today(), datetime.min.time())) #previous utc day
            hist_resp1=weather_api_call(lat,long,dt1,Weather_API_KEY)
            main_list=[]
            for i in hist_resp1.json()['hourly']:
                main_list.append([i['dt'],i['pressure'],i['dew_point'],i['humidity'],i['temp'],i['wind_speed']])

            dt2=get_today_unix(date.today()) #new UTC day
            hist_resp2=weather_api_call(lat,long,dt2,Weather_API_KEY)
            for i in hist_resp2.json()['hourly']:
                main_list.append([i['dt'],i['pressure'],i['dew_point'],i['humidity'],i['temp'],i['wind_speed']])
            
            df=pd.DataFrame(main_list,columns=['date','Barometric_Pressure','Dewpoint','Relative_Humidity','Temperature','Wind_Speed'])

            df['date']=df.date.apply(change_date)
            
        elif time(21,0) <= datetime.now().time() < time(23,59):
            dt_in=datetime.today().replace(hour=17, minute=0, second=0, microsecond=0)
            dt=get_today_unix(dt_in)
            hist_resp=weather_api_call(lat,long,dt,Weather_API_KEY)
            main_list=[]
            for i in hist_resp.json()['hourly']:
                main_list.append([i['dt'],i['pressure'],i['dew_point'],i['humidity'],i['temp'],i['wind_speed']])

            df=pd.DataFrame(main_list,columns=['date','Barometric_Pressure','Dewpoint','Relative_Humidity','Temperature','Wind_Speed'])

            df['date']=df.date.apply(change_date)

        else:
            from datetime import datetime, time, timedelta, date
            dt=get_today_unix(date.today())
            hist_resp=weather_api_call(lat,long,dt,Weather_API_KEY)
            main_list=[]
            for i in hist_resp.json()['hourly']:
                main_list.append([i['dt'],i['pressure'],i['dew_point'],i['humidity'],i['temp'],i['wind_speed']])

            df=pd.DataFrame(main_list,columns=['date','Barometric_Pressure','Dewpoint','Relative_Humidity','Temperature','Wind_Speed'])

            df['date']=df.date.apply(change_date)
            
            
        df['date'] = pd.to_datetime(df['date'])
        df.sort_values(by=['date'],inplace=True)
        df['Wind_Speed']=df.Wind_Speed.apply(wind_speed_change)
        #Now code for getting air quality data for last 5 hours
        hours = 5
        current_date_and_time = datetime.today().replace( minute=0, second=0, microsecond=0) #datetime.now()

        hours_added = timedelta(hours = hours)

        start_hour = current_date_and_time - hours_added

        start_time=get_today_unix(start_hour)
        end_hour=datetime.today().replace( minute=0, second=0, microsecond=0)
        end_time=get_today_unix(end_hour)
        
        req2=requests.get(f'http://api.openweathermap.org/data/2.5/air_pollution/history?lat={lat}&lon={long}&start={start_time}&end={end_time}&appid={Weather_API_KEY}')
        
        air_list=[]
        for i in (req2.json()['list']):
            air_list.append([i['dt'],i['components']['co'],i['components']['no2'],i['components']['o3'],i['components']['pm10'],i['components']['pm2_5'],i['components']['so2']])
        
        df_air=pd.DataFrame(air_list,columns=['date','CO','NO2','OZONE','PM10','PM25','SO2'])

        df_air['date']=df_air.date.apply(change_date)

        df_air['date'] = pd.to_datetime(df_air['date'])
        df_air.sort_values(by=['date'],inplace=True)
        
        df_air['CO']=df_air['CO'].apply(ppm_unit)
        df_air['NO2']=df_air['NO2'].apply(ppm_unit)
        df_air['OZONE']=df_air['OZONE'].apply(ppm_unit)
        df_air['SO2']=df_air['SO2'].apply(ppm_unit)

        
        new_df=pd.concat([df_air.drop(columns='date').tail(5).reset_index(),df.drop(columns='date').tail(5).reset_index()],axis=1)
        new_df.drop(columns='index',inplace=True)
        
        #Dataset to hold final results
        df_model_results = pd.DataFrame(columns = ['CO_Predicted','AQI_CO_Predicted',
                                                   'Ozone_Predicted','AQI_Ozone_Predicted',
                                                   'PM25_Predicted','AQI_PM25_Predicted',
                                                   'PM10_Predicted','AQI_PM10_Predicted',
                                                   'Final_AQI_Predicted'])
                                                   
       #scale values using pickled scaler
        columns_transform=list(new_df.columns) #numerical columns to be transformed.
        values=new_df.values
        scaled=scaler.fit_transform(values)
        df_transformed=pd.DataFrame(scaled,columns=new_df.columns)
        
        #Add Dummy Row
        series_obj = pd.Series( [0,0,0,0,0,0,0,0,0,0,0], 
                                index=df_transformed.columns )


        # Add a series as a row to the dataframe  
        mod_df = df_transformed.append(  series_obj,
                                ignore_index=True)
                                
        #load all the models                        
        model_CO = tf.keras.models.load_model('best_model_CO.h5')
        model_Ozone = tf.keras.models.load_model('best_model_Ozone.h5')

        Pkl_Filename = "best_model_PM25.pkl"  
        # Load the Model back from file
        with open(Pkl_Filename, 'rb') as file:  
            model_PM25 = pickle.load(file)
            
        Pkl_Filename = "best_model_PM10.pkl"  
        # Load the Model back from file
        with open(Pkl_Filename, 'rb') as file:  
            model_PM10 = pickle.load(file)
            
        #CO Prediction
        # specify the number of lag hours
        n_hours = 5
        n_features = 9 #number of features in dataframe to be used

        # frame as supervised learning with previous 5 hours data to predict upcoming hour data.
        scaled_CO=mod_df.iloc[:,[0,1,2,3,5,6,8,9,10]].values
        reframed_CO = series_to_supervised(scaled_CO, n_hours, 1)
        print(reframed_CO.shape)

        CO_X=data_split(reframed_CO,n_hours,n_features,'yes')

        yhat=model_CO.predict(CO_X)
        yhat = np.repeat(yhat, 11, axis=-1)
        inv_yhat = scaler.inverse_transform(yhat)[:,0]
        df_model_results['CO_Predicted']=inv_yhat
        df_model_results['AQI_CO_Predicted']=df_model_results.CO_Predicted.apply(AQI_cal,pollutant='CO') 
        
        #Ozone Prediction
        # specify the number of lag hours
        n_hours = 5
        n_features = 6 #number of features in dataframe to be used

        # frame as supervised learning with previous 5 hours data to predict upcoming hour data.
        scaled=mod_df.iloc[:,[2,0,1,8,9,10]].values
        reframed = series_to_supervised(scaled, n_hours, 1)
        print(reframed.shape)

        Ozone_X=data_split(reframed,n_hours,n_features,'yes')

        yhat=model_Ozone.predict(Ozone_X)
        yhat = np.repeat(yhat, 11, axis=-1)
        inv_yhat = scaler.inverse_transform(yhat)[:,2]
        df_model_results['Ozone_Predicted']=inv_yhat
        df_model_results['AQI_Ozone_Predicted']=df_model_results.Ozone_Predicted.apply(AQI_cal,pollutant='OZONE')
        
        #PM2.5 Prediction
        # specify the number of lag hours
        n_hours = 5
        n_features = 7 #number of features in dataframe to be used

        # frame as supervised learning with previous 5 hours data to predict upcoming hour data.
        scaled=mod_df.iloc[:,[4,3,6,7,8,9,10]].values
        reframed = series_to_supervised(scaled, n_hours, 1)
        print(reframed.shape)

        PM25_X=data_split(reframed,n_hours,n_features,'no')

        yhat=model_PM25.predict(PM25_X)
        yhat = np.repeat(yhat.reshape(-1,1), 11, axis=-1)
        inv_yhat = scaler.inverse_transform(yhat)[:,4]
        df_model_results['PM25_Predicted']=inv_yhat
        df_model_results['AQI_PM25_Predicted']=df_model_results.PM25_Predicted.apply(AQI_cal,pollutant='PM25')
        
        #PM10 Prediction
        # specify the number of lag hours
        n_hours = 5
        n_features = 7 #number of features in dataframe to be used

        # frame as supervised learning with previous 5 hours data to predict upcoming hour data.
        scaled=mod_df.iloc[:,[3,0,1,2,4,5,10]].values
        reframed = series_to_supervised(scaled, n_hours, 1)
        print(reframed.shape)

        PM10_X=data_split(reframed,n_hours,n_features,'no')

        yhat=model_PM10.predict(PM10_X)
        yhat = np.repeat(yhat.reshape(-1,1), 11, axis=-1)
        inv_yhat = scaler.inverse_transform(yhat)[:,3]
        df_model_results['PM10_Predicted']=inv_yhat
        df_model_results['AQI_PM10_Predicted']=df_model_results.PM10_Predicted.apply(AQI_cal,pollutant='PM10')
        
        df_model_results['Final_AQI_Predicted'] = (df_model_results[["AQI_CO_Predicted", "AQI_Ozone_Predicted",
                                                                 "AQI_PM25_Predicted", "AQI_PM10_Predicted"]].max(axis = 1))

        df_model_results['Predicted_AQI_LEVEL'] = df_model_results["Final_AQI_Predicted"].apply(AQI_level)
        
        CO=((round(df_model_results.CO_Predicted,2)).values)[0]
        Ozone=((round(df_model_results.Ozone_Predicted,4)).values)[0]
        PM25=((round(df_model_results.PM25_Predicted,2)).values)[0]
        PM10=((round(df_model_results.PM10_Predicted,2)).values)[0]
        AQI_l=df_model_results.Predicted_AQI_LEVEL.values[0]
        AQI_value=df_model_results.Final_AQI_Predicted.values[0]
        
        #Healthimpact prediction
        unix_dt=get_today_unix(date.today())
        
        # collect weather data
        resp1=weather_api_call(lat,long,unix_dt,Weather_API_KEY)
        sub_list=[]
        for i in resp1.json()['hourly']:
            sub_list.append([i['dt'],i['pressure'],i['dew_point'],i['humidity'],i['temp'],i['wind_speed']])
        
        temp=[]
        pres=[]
        wind=[]
        humid=[]
        dp=[]
        for eachhour in sub_list:
          date=eachhour[0]
          pres.append(eachhour[1])
          dp.append(eachhour[2])
          humid.append(eachhour[3])
          temp.append(eachhour[4])
          wind.append(eachhour[5])

        finalist=[]

        Temp_Maximum=max(temp)
        Temp_1_Day_Average=mean(temp)

        Pressure_1_Day_Average_mph=mean(pres)
        Pressure_Maximum_mph=max(pres)

        Wind_Maximum_mph=max(wind)
        Wind_1_Day_Average_mph=mean(wind)

        Dewpoint_Maximum_degF=max(dp)
        Dewpoint_1_Day_Average_degF=mean(dp)

        Rel_Humidity_Maximum=max(humid)
        Rel_Humidity_1_Day_Average=mean(humid)

        finalist.append([date,Temp_Maximum,Temp_1_Day_Average,Pressure_1_Day_Average_mph,Pressure_Maximum_mph,Wind_Maximum_mph,Wind_1_Day_Average_mph,Dewpoint_Maximum_degF,Dewpoint_1_Day_Average_degF,Rel_Humidity_Maximum,Rel_Humidity_1_Day_Average])
                
        df_weather=pd.DataFrame(finalist,columns=['date','Temp_Maximum','Temp_1_Day_Average','Pressure_1_Day_Average_mph','Pressure_Maximum_mph','Wind_Maximum_mph','Wind_1_Day_Average_mph','Dewpoint_Maximum_degF','Dewpoint_1_Day_Average_degF','Rel_Humidity_Maximum','Rel_Humidity_1_Day_Average'])
        df_weather['date']=df_weather.date.apply(change_date)
        
        #collect yearly airpollutants data
        start_hour = datetime.today().replace( month=1,day=1, hour=0,minute=0, second=0, microsecond=0)
        start_time=get_today_unix(start_hour)
        end_time=get_today_unix(datetime.today())
        resp2= air_pollutants_api_call(lat,long,start_time,end_time,Weather_API_KEY)
        
        air_poll=[]

        for i in (resp2.json()['list']):
          air_poll.append([i['dt'],i['components']['co'],i['components']['no2'],i['components']['o3'],i['components']['pm10'],i['components']['pm2_5'],i['components']['so2']])

        co=[]
        no2=[]
        o3=[]
        pm10=[]
        pm25=[]
        so2=[]
        for eachhour in air_poll:
          date=eachhour[0]
          co.append(eachhour[1])
          no2.append(eachhour[2])
          o3.append(eachhour[3])
          pm10.append(eachhour[4])
          pm25.append(eachhour[5])
          so2.append(eachhour[6])

        final_air_list=[]

        CO_Maximum=max(co)
        CO_Annual_Mean=mean(co)/35

        NO2_Maximum=max(no2)
        NO2_Annual_Mean=(mean(no2)) * 6

        O3_1_hr_maximum=max(o3)
        O3_8_hr_maximum=mean(o3)

        PM10_Maximum=max(pm10)
        PM10_Annual_Mean=mean(pm10)

        PM25_Maximum=max(pm25)
        PM25_Wtd_Mean=mean(pm25)

        SO2_Maximum=max(so2)
        SO2_Annual_Mean=(mean(so2) *  2.62)/30

        CO_Maximum=max(co)
        CO_Maximum=max(co)

        final_air_list.append([date,CO_Annual_Mean,NO2_Annual_Mean,SO2_Annual_Mean,PM25_Wtd_Mean,PM10_Annual_Mean,CO_Maximum,NO2_Maximum,SO2_Maximum,O3_1_hr_maximum,O3_8_hr_maximum,PM25_Maximum,PM10_Maximum])
               
        df_airpollutants=pd.DataFrame(final_air_list,columns=['date','CO_Annual_Mean','NO2_Annual_Mean','SO2_Annual_Mean','PM25_Wtd_Mean','PM10_Annual_Mean','CO_Maximum','NO2_Maximum','SO2_Maximum','O3_1_hr_maximum','O3_8_hr_maximum','PM25_Maximum','PM10_Maximum'])
        
        df_airpollutants['CO_Maximum']=df_airpollutants.CO_Maximum.apply(ppm_unit)
        df_airpollutants['NO2_Maximum']=df_airpollutants.NO2_Maximum.apply(ppm_unit)
        df_airpollutants['SO2_Maximum']=df_airpollutants.SO2_Maximum.apply(ppm_unit)
        df_airpollutants['O3_1_hr_maximum']=df_airpollutants.O3_1_hr_maximum.apply(ppm_unit)
        df_airpollutants['O3_8_hr_maximum']=df_airpollutants.O3_8_hr_maximum.apply(ppm_unit)
        df_airpollutants['date']=df_airpollutants.date.apply(change_date)
        
        # Create data for testing
        
        test_df=pd.DataFrame()
        test_df['Year'] = pd.Series(2021)
        def city_to_zipcode(city):
            loc_dict={"Salton City":92274,"Bombay Beach":92257,"Mecca":92254,"Westmorland":92281}
            return loc_dict[city]
             
        test_df['Zip_Code']=city_to_zipcode(city_name)
         
        def city_to_county(city):
            county_dict={"Salton City":1,"Bombay Beach":0,"Mecca":1,"Westmorland":0}
            return county_dict[city]
            
        test_df['county']=city_to_county(city_name) 

        test_df['City']=city_name
        test_df['Age_Group']='0-17'
        
        test_df=pd.concat([test_df,df_airpollutants,df_weather.drop(columns='date')],axis=1)
        test_df.drop(columns='date', inplace=True)
        
        # Loading model to compare the results
        model = pickle.load(open('model.pkl','rb'))

        # load the scaler
        scaler = pickle.load(open('minmaxscaler.pkl', 'rb'))
        target_scaler = pickle.load(open('targetscaler.pkl', 'rb'))
        
        # Converting cities to integer values
        def convert_to_int(word):
            word_dict = {'Bombay Beach':0, 'Brawley-220 Main Street':1, 'Buttercup':2, 'Cahuilla':3, 'Calexico-Ethel Street':4, 'Calipatria - Mulberry':5, 'Cathedral City':6, 'El Centro Naval Air Facility #2':7, 'El Centro-9th Street':8,
                          'Fish Creek Mountains':9, 'Imperial County Airport':10, 'Indio #3':11, 'Indio-Jackson Street':12,'Joshua Tree National Park':13, 'Joshua Tree NP-Cottonwood #2':14, 'La Quinta II':15, 'Mecca-65705 Johnson Street':16, 
                          'Mecca-66275 Martinez Road':17, 'Mecca':18, 'Meloland':19, 'Naval Test Base':20, 'Niland-English Road':21, 'Oasis':22, 'Palm Springs Regional Airport':23, 'Palm Springs-Fire Station':24, 'Palo Verde II':25,
                          'PINYON':26, 'Salton City':27,'Salton Sea East':28,'Salton Sea Park':29, 'Seeley':30, 'Sonny Bono':31, 'Squaw Lake':32, 'Thermal South':33,'Thermal-Jacqueline Cochran Regional Airport':34,'Torres-Martinez':35,'UC-Andrade':36,
                           'Westmorland':37,'Westmorland-W 1st Street':38}
            return word_dict[word]

        test_df['City'] = test_df['City'].apply(lambda x : convert_to_int(x))
        
        concat_df=pd.concat([test_df,test_df],axis=0)
        final_df=pd.concat([concat_df,test_df],axis=0)  
        final_df=final_df.reset_index(drop=True)
        final_df.loc[1,['Age_Group']] = '18+'
        final_df.loc[2,['Age_Group']] = 'All Ages'
        final_df= pd.concat([final_df, pd.get_dummies(final_df['Age_Group'], prefix = 'Age_Group')],axis=1)
        final_df.drop(['Age_Group'],axis=1, inplace=True)

        #Rename Age_group columns
        dict= {'Age_Group_0-17': 'Young_population',
               'Age_Group_18+': 'Adults_population',
               'Age_Group_All Ages':'General'
               }

        final_df.rename(columns= dict, inplace=True)
        
        final_df = scaler.transform(final_df)
        pred= model.predict(final_df)
        output=target_scaler.inverse_transform(pred.reshape(-1, 1))
        Children= output[0].round(2).item()
        Adults= output[1].round(2).item()
        General= output[2].round(2).item()

        
        return render_template('Hourly_Prediction.html', folium_map=True,post_return=True,loc_name=city_name,CO=CO,Ozone=Ozone,PM25=PM25,PM10=PM10,AQI_level=AQI_l,AQI=AQI_value,Children=Children,Adults=Adults,General=General)
               
    else:
        return render_template('Hourly_Prediction.html')
    
@app.route('/map')
def map():
    return render_template('map.html')
    
@app.route('/hourly_da') #Tableau Data anlytics 
def hourly_da():
    return render_template('hourly_da.html')
    

@app.route('/yearly_health', methods = ['GET','POST']) 
def yearly_health():
    if request.method=="POST":
        req=request.form
        year= req.get('Year')
        year= int(year)
        loc= req.get('Location')
        
        data= pd.read_csv('healthdata_actual_predictions.csv', encoding='unicode_escape')
        
                  
        result = data[(data['Year']== int(year)) & (data['City'] == loc)]
       
        if len(result) ==3:
            Young_actual=result[result['Age_group'] == 'Children'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]     
            Young_predict=result[result['Age_group'] == 'Children'].Predicted.values[0]
           
            Adult_actual=result[result['Age_group'] == 'Adults'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]
            Adult_predict=result[result['Age_group'] == 'Adults'].Predicted.values[0]
                
            General_actual=result[result['Age_group'] == 'General'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]
            General_predict=result[result['Age_group'] == 'General'].Predicted.values[0]
            
        elif len(result) ==2:
            Young_actual = 0 
            Young_predict= 0
            Adult_actual=result[result['Age_group'] == 'Adults'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]
            Adult_predict=result[result['Age_group'] == 'Adults'].Predicted.values[0]
                
            General_actual=result[result['Age_group'] == 'General'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]
            General_predict=result[result['Age_group'] == 'General'].Predicted.values[0]
            
        elif len(result) ==1:
            Young_actual = 0 
            Young_predict= 0
            Adult_actual=0
            Adult_predict=0
            General_actual=result[result['Age_group'] == 'General'].Age_Adjusted_Rate_of_Asthma_ED_V.values[0]
            General_predict=result[result['Age_group'] == 'General'].Predicted.values[0]
            
        else:
            return render_template('yearly_health.html',content="Data not found")
            
                
        area =result[result['Age_group'] == 'General'].county.values[0]
        CO = round(result[result['Age_group'] == 'General'].CO_Annual_Mean.values[0],2)
        NO2 = round(result[result['Age_group'] == 'General'].NO2_Annual_Mean.values[0],2)
        SO2 =round(result[result['Age_group'] == 'General'].SO2_Annual_Mean.values[0],2)
        PM25= round(result[result['Age_group'] == 'General'].PM25_1_Day_Average.values[0],2)
        PM10 =round(result[result['Age_group'] == 'General'].PM10_1_Day_Average.values[0],2)
        O3 = round(result[result['Age_group'] == 'General'].O3_8_hr_maximum.values[0],2)
            
        
        return render_template('yearly_health.html',post_return=True,Young_actual=Young_actual,Young_predict=Young_predict,year=year,loc=loc,Adult_actual=Adult_actual,Adult_predict=Adult_predict,General_actual=General_actual,General_predict=General_predict,
            area=area,CO=CO,NO2=NO2,SO2=SO2,PM25=PM25,PM10=PM10,O3=O3)
           
        
    else:
        return render_template('yearly_health.html')
 
    
@app.route('/health_da') 
def health_da():
    return render_template('health_da.html')

@app.route('/PM_map') 
def PM_map():
    return render_template('pm_map.html')

@app.route('/historical_pm') 
def historical_pm():
    return render_template('historical_pm.html')


#app.run(debug = True)

if __name__ == '__main__':
    #app.run(debug=True)
    app.run(host='127.0.0.1', port=8080)