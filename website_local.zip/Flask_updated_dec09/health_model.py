import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn import preprocessing
from sklearn import metrics
from sklearn.linear_model import Ridge, Lasso, ElasticNet
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import VotingRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import StackingRegressor
from sklearn.linear_model import LinearRegression



data=pd.read_csv('final_mapped_data_v1.csv', encoding='unicode_escape')

data= pd.concat([data, pd.get_dummies(data['Age_Group'], prefix = 'Age_Group')],axis=1)
data.drop(['Age_Group','Number_of_Asthma_ED_Visits'],axis=1, inplace=True)

#Rename Age_group columns
dict= {'Age_Group_0-17': 'Young_population',
       'Age_Group_18+': 'Adults_population',
       'Age_Group_All Ages':'General'
       }

data.rename(columns= dict, inplace=True)



# Converting counties to integer values
def convert_to_int(word):
     word_dict= {'Imperial':0,'Riverside':1}
     return word_dict[word]

data['county'] = (data['county'].apply(lambda x : convert_to_int(x)))

# Converting cities to integer values
def convert_to_int(word):
    word_dict = {'Bombay Beach':0, 'Brawley-220 Main Street':1, 'Buttercup':2, 'Cahuilla':3, 'Calexico-Ethel Street':4, 'Calipatria - Mulberry':5, 'Cathedral City':6, 'El Centro Naval Air Facility #2':7, 'El Centro-9th Street':8,
                  'Fish Creek Mountains':9, 'Imperial County Airport':10, 'Indio #3':11, 'Indio-Jackson Street':12,'Joshua Tree National Park':13, 'Joshua Tree NP-Cottonwood #2':14, 'La Quinta II':15, 'Mecca-65705 Johnson Street':16, 
                  'Mecca-66275 Martinez Road':17, 'Mecca-90-333 Avenue':18, 'Meloland':19, 'Naval Test Base':20, 'Niland-English Road':21, 'Oasis':22, 'Palm Springs Regional Airport':23, 'Palm Springs-Fire Station':24, 'Palo Verde II':25,
                  'PINYON':26, 'Salton City':27,'Salton Sea East':28,'Salton Sea Park':29, 'Seeley':30, 'Sonny Bono':31, 'Squaw Lake':32, 'Thermal South':33,'Thermal-Jacqueline Cochran Regional Airport':34,'Torres-Martinez':35,'UC-Andrade':36,
                   'Westmorland North':37,'Westmorland-W 1st Street':38}
    return word_dict[word]

data['City'] = data['City'].apply(lambda x : convert_to_int(x))


X=data.loc[:, data.columns!= 'Age_Adjusted_Rate_of_Asthma_ED_V']  
Y=data[['Age_Adjusted_Rate_of_Asthma_ED_V']]
Y=Y.values.reshape(-1,1)   



#Split dataset into training set and test set
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2,random_state=42) # 80% training and 20% test


scaler = preprocessing.MinMaxScaler()
scaler.fit(X_train)
X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

target_scaler =preprocessing.MinMaxScaler()
target_scaler.fit(y_train)

# transform target variables
y_train = target_scaler.transform(y_train)
y_test = target_scaler.transform(y_test)



estimators = [('rfr', RandomForestRegressor(criterion='mse', max_depth = 50, n_estimators= 100, max_features =20, random_state = 42)),
              ('svr', SVR(kernel='rbf', gamma='auto', C= 100, epsilon= 0.01)),
              ('enr', ElasticNet(alpha= 0.0001, l1_ratio=0.5, max_iter =5000)),
               ('gbr', GradientBoostingRegressor(n_estimators=500, max_features=20,random_state = 42))]


reg = StackingRegressor(estimators=estimators,final_estimator= LinearRegression())

reg.fit(X_train, y_train)


# Saving model to disk
pickle.dump(reg, open('model.pkl','wb'))

# save the scaler
pickle.dump(scaler, open('minmaxscaler.pkl', 'wb'))

pickle.dump(target_scaler, open('targetscaler.pkl', 'wb'))

